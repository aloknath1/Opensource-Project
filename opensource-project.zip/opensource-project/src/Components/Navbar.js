import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class Navbar extends Component {
  
  handleSearch(){

  }

  render() {
      
    return (
      <div id="custom-bootstrap-menu" className="navbar navbar-default navbar-fixed-top" role="navigation">
          <div className="container-fluid">
            <div className="navbar-header"><img className="navbar-brand" src="/img/cerner_logo.png"/> 
            <a className="navbar-brand" href="#">header</a>
              <button type="button" className="navbar-toggle" data-toggle="collapse" data-target=".navbar-menubuilder">
                <span className="sr-only">Toggle navigation</span>
                <span className="icon-bar"></span><span className="icon-bar"></span>
                <span className="icon-bar"></span>
              </button>
            </div>
            <div className="collapse navbar-collapse navbar-menubuilder">
              <ul className="nav navbar-nav navbar-left">
                <li><a href="/">Home</a></li>
                <li><a href="/createTeam">Teams</a></li>
                <li><a href="/contact">Contact</a></li>
                <li><a href="/licenses">DisplayLicenses</a></li>
              </ul>
              <form method="get" className="navbar-form navbar-left" onSubmit={this.handleSearch.bind(this)}>
                <div className="form-group">
                  <input name="q" type="text" className="form-control" placeholder="Search for..." value="{{searchQuery}}" />
                  <span className="form-group-btn">
                    <button type="submit" className="btn btn-default" type="button">Search</button>
                  </span>
                </div>
              </form>
              <ul className="nav navbar-nav navbar-right">
                <li><a href="#user">Alok</a>
                </li>
                <li><a href="#">logAction</a>
                </li>
              </ul>
            </div>
          </div>
        </div> 
    );
  }
}

export default Navbar;