import React, { Component } from 'react';

class DisplayDependencies extends Component {

   render() {
      
    return (
       <div>        
         <div id="details">
        	<table class="table">
				<thead class="thead-inverse">
				<tr>
					<th>DependencyName</th>
					<th>CurrentVersion</th>
					<th>LatestVersion</th>
					<th>DependencyLicence</th>

				</tr>
				</thead>
				<tbody>
				
					<tr>
						<td>{{artifactName}}</td>
						<td>{{currentVersion}}</td>
						<td>{{latestVersion}}</td>
						<td>
						Licencies
						</td>
					</tr>
				
				</tbody>
			</table>
        </div>
        <div id="graph">
			<script>
				Morris.Donut({
 					element: 'graph',
					data: JSON.parse('{{{pieChartJSONData}}}'),
  					formatter: function (x) { return x + "%"}
					}).on('click', function(i, row){
  						console.log(i, row);
					});
			</script>
		</div> 
      </div>
    );
  }
}

export default DisplayDependencies;