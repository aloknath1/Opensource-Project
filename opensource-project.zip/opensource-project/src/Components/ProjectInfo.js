import React, { Component } from 'react';

class ProjectInfo extends Component {

   render() {
    return (
     <div id="project_info" className="Projects">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-offset-1 col-md-10 col-lg-offset-1 col-lg-10">
                  <table className="project_table">
                      <thead>
                          <tr>
                              <th>#id</th>
                              <th>Team</th>
                              <th>Project</th>
                              <th>License</th>
                          </tr>
                      </thead>
                      <tbody>
                          
                          <tr>
                              <td data-label="id">Id</td>
                              <td data-label="team">team</td>
                              <td data-label="project">Project</td>
                              <td data-label="license">License</td>
                          </tr>                           
                      </tbody>
                  </table>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ProjectInfo;