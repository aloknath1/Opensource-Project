import React, { Component } from 'react';

class DisplayLicense extends Component {

   render() {
      
    return (
       <div>        
	<div className="container custom">
	  <ul id="pills" className="nav nav-pills custom">
		  <li className="active"><a data-toggle="tab">All</a></li>             
	  </ul>
	  <br/>
	  <div>   
		  <table className="table table-nonfluid" id="licenses">
			  <thead>
				  <tr>
					  <th>License Name</th>
					  <th>License Status</th>
				  </tr>
			  </thead>
			  <tbody id="licenseDetails"></tbody>
		  </table>
	  </div>
	  <br/><br/>            
	  <button type="button" className="btn btn-info btn-sm" data-toggle="modal" data-target="#addLicense">Add License</button>
	</div>
       
  <div className="modal fade" id="addLicense" role="dialog">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <button type="button" className="close" data-dismiss="modal">&times;</button>
          <h4 className="modal-title">Add License</h4>
        </div>
        <div className="modal-body">
          <form id="add" method="post">
                License Name:<br/>
                <input type="text" name="license_name" />
                <br/>
                License Status:<br/>  
                <br/>
                License URL:<br/>
                <input type="url" name="license_url" style="width: 300px;" /><br/>
                <br/><br/>
                <input type="submit" value="Submit" />
            </form> 
        </div>
      </div>     
    </div>
    </div>

        <div className="modal fade" id="update" role="dialog">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <button type="button" className="close" data-dismiss="modal">&times;</button>
          <h4 className="modal-title">Update License</h4>
        </div>
        <div className="modal-body">
          <ul className="nav nav-pills">
            <li className="active"><a data-toggle="pill" href="#status">Status</a></li>
            <li><a data-toggle="pill" href="#url">URL</a></li>
        </ul>
        <div className="tab-content">
            <div id="status" className="tab-pane fade in active">
                <div>
                    <form onsubmit="postLicenses('updateStatus'); return false;" id = "updateStatus" method="post">
                        License Name:<br/>
                        <input type="text" name="license_name" />
                        <br/>
                        License Status:<br/>
                        <select name="license_status">
                           
                        </select>
                        <br/><br/>
                        <input type="submit" value="Submit" />
                    </form> 
                </div>
            </div>

            <div id="url" className="tab-pane fade">
                <div>
                    <form id="updateURL" method="post">
                        License Name:<br/>
                        <input type="text" name="license_name" /><br/>
                        License URL:<br/>
                        <input type="url" name="license_url" />
                        <br/><br/>
                        <input type="submit" value="Submit" />
                    </form> 
                </div>
            </div>
        </div>
        </div>
      </div>     
    </div>
    </div>

      </div>
    );
  }
}

export default DisplayLicense;