import React, { Component } from 'react';

class Dependencies extends Component {

   render() {
      
    return (
       <div>        
        <table class="table">
          <thead class="thead-inverse">
              <tr>
                  <th>DependencyName</th>
                  <th>CurrentVersion</th>
                  <th>LatestVersion</th>
                  <th>DependencyLicence</th>
              </tr>
          </thead>
          <tbody>             
                <tr>
                    <td>{{name}}</td>
                    <td>{{version}}</td>
                    <td>{{recentVersion}}</td>
                    <td>{{dependencyLicenses}}</td>
                </tr>              
          </tbody>
      </table>
      </div>
    );
  }
}

export default Dependencies;