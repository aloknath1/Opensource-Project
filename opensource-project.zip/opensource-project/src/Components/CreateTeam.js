import React, { Component } from 'react';

class CreateTeam extends Component {
 
  render() {
      
    return (
     <div class="Team">
        <div id="create_team" class="tab-content container">
            <h2 class="create_team_header">header</h2>
            <div id="createTeam" class="tab-pane active">
                <table class="table table-striped " id="create_team_table">
                    <thead>
                        <tr>
                            <th class="col-md-2">Team Name</th>
                            <th class="col-md-1">Action</th>
                            <th class="col-md-2"> </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr id="new-team">
                            <td ><input type="text" class="form-control" id="team_name_input" /></td>
                            <td>
                                <button type="button" class="btn btn-primary" id="create_team_button">Add</button>
                            </td> 
                            <td>
                                 <div class="alert alert-danger alert-dismissable" id = "alert-danger">
                                    <a href="#" class="close" id = "alert-close">&times;</a>
                                 </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>


       <div id="exist_team" class="tab-content container">
            <h2 class="exist_team_header">header</h2>
            <div id="existTeam" class="tab-pane active">
                <table class="table table-striped " id="exist_team_table">
                    <thead>
                        <tr>
                            <row>
                                <th class="col-md-3">Team Name</th>
                                <th class="col-md-4">Action</th>
                            </row>
                        </tr>
                    </thead>
                    <tbody>
                        
                         <tr id="{{teamName}}">
                            <td  class="col-md-3" id = "teamName">teamName</td>
                            <td class="col-md-4">
                                <button type="button" class="btn btn-primary" >  Delete </button>
                            </td>
                         </tr>
                       
                    </tbody>
                </table>
            </div>
        </div>

       </div>
    );
  }
}

export default CreateTeam;