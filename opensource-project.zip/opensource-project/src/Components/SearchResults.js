import React, { Component } from 'react';

class SearchResults extends Component {
  
  render() {
      
    return (
      <div id="search_results">
           <div className="container">
        <ul className="nav nav-pills">
            <li className="active"><a data-toggle="pill" href="#repos">Repositories [20]</a></li>
            <li><a data-toggle="pill" href="#users">Users [40]</a></li>
        </ul>
        <br>
        <div className="tab-content">
            <div id="repos" className="tab-pane fade in active">
              
                <div className=" col-md-offset-2 col-md-8">
                    <div className="list-group">
                      
                        <a type="button" className="list-group-item search_item">
                                <h3>{{full_name}}</h3>
                                <p>{{description}}</p>
                                <p>{{statusSummary}}</p>
                                <div className="button-container">
                                  <form action="#" method="get">
                                	<button type="submit" className="btn btn-default" type="button">Add</button>
                                	<input type = "hidden" name="fullName" type="text" className="form-control" value="{{full_name}}" />
                                	<button type="submit" formaction="/displayDependencies" className="btn btn-default" type="button">GetDependencies</button>
                                	<button type="submit" formaction="/downloadDataControl" className="btn btn-default" type="button">DownloadDependencies</button>
                                 </form>
                                </div>
                            </a>
                        
                    </div>
                </div>
               
            </div>

            <div id="users" className="tab-pane fade">
              
                <div className=" col-md-offset-2 col-md-8">
                    <div className="list-group">
                       
                        <a type="button" className="list-group-item search_item">
                                <h3>{{fullname}}</h3>
                                <p>{{login}}</p>
                                <div className="button-container">
                                  <form action="#" method="get">
                                    <input type = "hidden" name="userName" type="text" className="form-control" value="login" />
                                 </form>
                                </div>
                            </a>                
                      
                    </div>
                </div>
               
            </div>
        </div>
    </div>
      </div> 
    );
  }
}

export default SearchResults;