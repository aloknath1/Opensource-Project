import React, { Component } from 'react';

class Contact extends Component {

    render() {
      
      
    return (
      <div className="Contact">    
           <div class="container">
        <div class="row">
          <div class="col-md-12">
            <form id="contact-form">
              <div class="form-group center-block">
                <label for="inputName">Name</label>
                <input type="text" class="form-control contact-input" id="inputName" placeholder="Enter Name" name="inputName" />
              </div>
              <div class="form-group center-block">
                <label for="inputEmail">Email</label>
                <input type="email" class="form-control contact-input" id="inputEmail" placeholder="Enter Email" name="inputEmail" />
              </div>
              <div class="form-group center-block">
                <label for="inputMessage">Message</label>
                <textarea id="inputMessage" class="form-control contact-input" rows="3" placeholder="Enter Message" name="inputMessage"></textarea>
              </div>
              <input type="text" name="_gotcha" class="display-none"/>
              <div class="text-center">
                <button class="btn btn-default" type="submit" id="email-submit-btn" value="Send">Submit</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      </div>
    );
  }
}

export default Contact;