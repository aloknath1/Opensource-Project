import React, { Component } from 'react';

class TeamSidebar extends Component {
  
  render() {
      
    return (
      <div id="team_sidebar">
           <div className="col-sm-3 col-md-2 sidebar" id="accordion">
                <ul className="nav nav-stacked group" id="teams">
                    <li><a href="#" className="heading">Teams</a></li>                   
                    <li>
                        <a data-toggle="collapse" href="#{{team}}" class="teams">{{team}}</a>
                        <div id="{{team}}" class=" collapse">
                            <ul class="list-group">
                                <li class="list-group-item"><a href="" class="subheading">teamsidebar.projects</a></li>
                                <li class="list-group-item"><a href="#" class="sublist">Project</a></li>                                   
                            </ul>
                        </div>
                    </li>                 
                </ul>
            </div>
      </div> 
    );
  }
}

export default TeamSidebar;