import React, { Component } from 'react';

class UserInfo extends Component {
  
  render() {
      
    return (
      <div id="user_info">
        <div className="container">
          <div className="row panel">
            <div className="col-md-4 bg_blur"></div>           
            <div className="col-md-8  col-xs-12">
              <img src="#" alt="" className="img-thumbnail visible-xs picture_mob" />
              <div className="header">
                  <h1 id="name">alok</h1>
                  <br/>
                  <span id="email">xyz@gmail.com</span>              
              </div>
            </div>
            </div>
        </div>           
    </div> 
    );
  }
}

export default UserInfo;