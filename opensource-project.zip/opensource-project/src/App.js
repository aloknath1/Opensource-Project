import React, { Component } from 'react';

import Navbar from './Components/Navbar';
import UserInfo from './Components/UserInfo';
import ProjectInfo from './Components/ProjectInfo';
import CreateTeam from './Components/CreateTeam';



import './App.css';

class App extends Component {
  constructor()
  {
    super();
   
  }

 render() {
    return (  

      <div className="App">       
			  	<Navbar />
          <UserInfo />
          <ProjectInfo />
      </div>
    );
  }
}

export default App;
