import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom';
import './index.css';
import App from './App';
import CreateTeam from './Components/CreateTeam';
import Contact from './Components/Contact';
import DisplayLicense from './Components/DisplayLicense';

 <BrowserRouter>
    <Switch>
      <Route path='createTeam' component={CreateTeam} />    
       <Route path='contact' component={Contact} />    
        <Route path='license' component={DisplayLicense} />    
    </Switch>
  </BrowserRouter>

ReactDOM.render(
                <App />, 
                document.getElementById('root')
                );