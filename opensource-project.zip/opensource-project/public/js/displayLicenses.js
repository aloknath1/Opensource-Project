// This method is used to add rows to the table
// when the page first loads.
function initializeTable()
{
    getLicenses('All')
}

// This function creates an AJAX request to the displayLicenses controller 
// to get a list of licenses with a particular status and then calls
// update table function with the response as a argument.
// parameter: type, the status type of the license being requested.
function getLicenses(type){

    var ajaxRequest = new XMLHttpRequest() 
    ajaxRequest.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            updateTable(this.responseText, window)    
        }
    }
    ajaxRequest.open('GET', '/licenses?type='+type, true)
    ajaxRequest.send()
}

// This method parses the JSON response and then 
// updates the table element accordingly.
// parameter: responseText, the JSON response with the license details.
// parameter: window_object, injected global scope that is used to redirect to the error page in case there is an exception.
function updateTable(responseText, window_object){
    try{
        var licenceList = JSON.parse(responseText)
    }catch(SyntaxError){
    	console.log("error occured while parsing returned response: "+responseText)
        window_object.location.href = '/error'
        return
    }
    
    var tbody = document.getElementById('licenseDetails')
    tbody.innerHTML = ''
    licenceList.forEach(function(element){
        tbody.innerHTML = tbody.innerHTML +'<tr>'+
            '<td><a href="'+element.licenseURL+'">'+ element.licenseName +'</a></td>'+
            '<td><span class = "'+removeWhitespace(element.status.text)+'"'+ '>'+element.status.text+'</span></td>'+
            '<td><button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#update" onclick="updateForm(&quot;'+element.licenseName+'&quot;)">Update</button></td>'+
            '</tr>'
    })
}

// This method handles the post requests that
// are made to handle new licenses.
// parameter: requestType, the type of request that needs to be made i.e add, updateStatus, updateURL.
function postLicenses(requestType)
{
    var query = '?type='+requestType
    var myForm = document.getElementById(requestType)
    if(requestType=='add')
    {
        query = query+'&licenseName='+myForm.license_name.value+'&licenseURL='+myForm.license_url.value+'&licenseStatus='+myForm.license_status.value
    }
    else if(requestType=='updateStatus')
    {
        query = query+'&licenseName='+myForm.license_name.value+'&licenseStatus='+myForm.license_status.value
    }
    else if(requestType=='updateURL')
    {
        query = query+'&licenseName='+myForm.license_name.value+'&licenseURL='+myForm.license_url.value
    }
    else
    {
        throw new Error('Unknown request type')
    }
    
    var ajaxRequest = new XMLHttpRequest()
    ajaxRequest.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            if(this.responseText == 'success')
            {
                reloadTab(myForm.license_status, window)
                myForm.reset()
            }
            else
                throw new Error('The request was unsuccessfull')   
        }
    }
    ajaxRequest.open('POST', '/licenses'+query, true)
    ajaxRequest.send()
    if(requestType=='add')
    {
        $('#addLicense').modal('hide')
    }
    else
    {
        $('#update').modal('hide')
    }
}

// This method reloads a sets the appropriate pill as active and updates the table
// if the status or url of a license is changed or a new license is added.
// parameter: status, the status of the object that was changed, can be null in case of the updateURL query.
// parameter: window_object, injected global scope. 
function reloadTab(status, window_object)
{
    if(status==null)
    {
        window_object.getLicenses($('#pills li.active').text())
        return null
    }
    var pills = $('#pills a')
    for(var i=0;i<pills.length;i++)
    {
        if(pills[i].innerText == status.value)
        {
            $('#pills li:eq('+i+') a').tab('show')
            window_object.getLicenses(pills[i].innerText)
            break
        }        
    }
}

// This is a helper function that is used to remove () and spaces 
// from strings so that they can be used in the markup or for sending.
// HTTP requests.
// parameter: text, from which special characters should be removed.
// return: lowercase string with no () or spaces.
function removeWhitespace(text)
{
    return ((text.replace(/ /g,'')).replace(/[\(\)']+/g,'')).toLowerCase()
}

// This method is used to update the form values when a license needs to be updated
// and sets the license name to the one that needs to be updated and then disables it
// so the user is not able to make any changes.
function updateForm(licenseName)
{
    var urlForm = document.getElementById('updateURL') 
    var statusForm = document.getElementById('updateStatus')
    urlForm.license_name.value = licenseName
    statusForm.license_name.value = licenseName
    urlForm.license_name.disabled =true
    statusForm.license_name.disabled =true
}