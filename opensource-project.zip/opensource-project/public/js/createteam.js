/**
 * createteam.js contains functions that handles addition and deletion
 * functionality of team from user interface.
 * 
 * @author SA050870 MK052898
 */

var RESPONSE_SUCCESS= 'success';
var RESPONSE_FAIL_INPUT_EMPTY = 'failure::inputEmpty';
var RESPONSE_INVALID_CHAR = 'failure::invalidChar';
var RESPONSE_FAIL_DUPLICATE_TEAM = 'failure::valueExists';
var RESPONSE_FAIL_TEAM_MEMBER_EXISTS = 'failure::teamMemberExists';
var RESPONSE_ERROR_AT_SERVER = 'failure::errorAtServer';
var MESSAGE_TEAM_NAME_ALREADY_EXISTS = 'Team name already used';
var MESSAGE_INVALID_CHARACTER_USED = 'Team name contains invalid character';
var MESSAGE_FAILED_TO_CONNECT_SERVER = 'Could not connect to the server';
var MESSAGE_TEAM_NAME_EMPTY = 'Team name cannot be empty';
var MESSAGE_ERROR_OCCURED = 'Error at server';
var MESSAGE_DELETE_SUCCESS = 'Delete successful!'
var MESSAGE_TEAM_MEMBER_ALREADY_ADDED = 'Team member already added';
var MESSAGE_TEAM_MEMBER_EMPTY = 'Team member cannot be empty';

const AJAX_REQUEST_COMPLETE = 4;

$(document).ready(onDocumentReadyCallBack);

/**
 * 
 * It is the callback for the jquery $(document).ready()
 * function. It attaches proper call backs to different html controlls to create
 * a team, delete a team, show various error messages.
 * 
 * @returns none
 */
function onDocumentReadyCallBack() 
{
    $('#team_name_input').focus(createTeamTextInputFieldOnFocusCallBack);
    $('#create_team_button').click(createTeamButtonOnClickCallBack);
    $('#alert-danger').hide();
}

/**
 * It is the on click call back for the html
 * element with id delete-teamName. When invoked, this method retrieves team
 * name from the text input field with id teamName and removes it. it makes a
 * ajax call to the server requesting to delete the team name from the database.
 * 
 * @param teamName
 *            is the object of the delete row
 * @returns none
 */
function deleteTeamButtonOnClickCallBack(teamName)
{	 
	    $('#' + teamName).remove();
		ajaxHTTPRequest = getXMLHttpRequestObject();
	    ajaxHTTPRequest.onreadystatechange = ajaxCallBackForDeleteTeamPostRequest;
	    ajaxHTTPRequest.open('POST', 'createTeam', true);
	    ajaxHTTPRequest.setRequestHeader('Content-type',
	            'application/x-www-form-urlencoded');
	    var requestParameter = 'teamName=' + teamName + '&actionType=Delete';
	    ajaxHTTPRequest.send(requestParameter);   
}

/**
 * The function is used as a call back for the
 * XMLHttpRequest object used for that makes a POST request on the server to
 * delete a team. If the connection to server was successful, it checks server
 * response. If the server deleted the team name from database then this
 * function shows an successful alert message If the server does not delete the
 * teamName from the database then this function shows proper error alert
 * message. If it cannot connect to the server, it shows an error alert message.
 * 
 * @returns none
 */
function ajaxCallBackForDeleteTeamPostRequest()
{
	  if (this.readyState === AJAX_REQUEST_COMPLETE && this.status === 200) 
	  {
	        if (this.response == RESPONSE_SUCCESS)
	        {
	        	alert(MESSAGE_DELETE_SUCCESS);
	        }
	        else
	        {
	        	alert(MESSAGE_ERROR_OCCURED);
	        }
	    }
}

/**
 * On focus call back for the html tag with id team_name_input which is used for
 * text input purposes. When the input field is clicked, this method hides the
 * warning message regarding failed attempt of a team creation.
 * 
 * @returns none
 */
function createTeamTextInputFieldOnFocusCallBack() 
{
	 $('#alert-danger').hide();
}

/**
 * The function is the on click call back for the html
 * element with id create_team_button. When invoked, this method retrieves team
 * name from the text input field with id team_name_input and validates it. If
 * the team name passes the validation it makes a ajax call to the server
 * requesting to insert the team name into the database. If the team name is
 * invalid, it makes a function call to show proper error message.
 * 
 * @returns none
 */
function createTeamButtonOnClickCallBack() 
{
    teamName = $('#team_name_input').val();
    teamName = teamName.trim();
    if(!teamName)
    {
        setErrorTextAndShow(MESSAGE_TEAM_NAME_EMPTY);
        console.log(MESSAGE_TEAM_NAME_EMPTY + ' ' + teamName);
        return;
    }
    invalidCharacters = getInvalidCharacters(teamName);
    if (invalidCharacters) 
    {
        setErrorTextAndShow(MESSAGE_INVALID_CHARACTER_USED, invalidCharacters);
        console.log(MESSAGE_INVALID_CHARACTER_USED + ' ' + invalidCharacters);
        return;
    }
    ajaxHTTPRequest = getXMLHttpRequestObject();
    ajaxHTTPRequest.onreadystatechange = ajaxCallBackForCreateTeamPostRequest;
    ajaxHTTPRequest.open('POST', 'createTeam', true);
    ajaxHTTPRequest.setRequestHeader('Content-type',
            'application/x-www-form-urlencoded');
    var requestParameter = 'teamName=' + teamName + '&actionType=Add';
    ajaxHTTPRequest.send(requestParameter);
}

/**
 * The function is used as a call back for the
 * XMLHttpRequest object used for that makes a POST request on the server to add
 * a team. If the connection to server was successful, it checks server
 * response. If the server added the team name into database then this function
 * shows the newly added team to a new row. If the server does not add the
 * teamName in the database then this function shows proper error messages. If
 * it cannot connect to the server, it shows an error message.
 * 
 * @returns none
 */
function ajaxCallBackForCreateTeamPostRequest()
{
    if (this.readyState === AJAX_REQUEST_COMPLETE && this.status === 200) 
    {
        if (this.response === RESPONSE_SUCCESS)
        {
            teamName = $('#team_name_input').val();
            $('#team_name_input').val('');
            setTimeout(function(){
                location.reload();
           }, 1000); 
        }
        else if(this.response === RESPONSE_FAIL_INPUT_EMPTY)
        {
            setErrorTextAndShow(MESSAGE_TEAM_NAME_EMPTY);
        }
        else if(this.response === RESPONSE_FAIL_DUPLICATE_TEAM)
        {
            setErrorTextAndShow(MESSAGE_TEAM_NAME_ALREADY_EXISTS);
        }
        else
        {
            setErrorTextAndShow(MESSAGE_ERROR_OCCURED);
        }
    }
};

/**
 * The function is the on click call back for the html element with id
 * addTeamMember-teamName button.
 * 
 * @param teamName
 *            the team name
 * @returns none
 */
function addTeamMemberButtonOnClick(teamName) 
{
	teamNameVal = teamName.id;
	$('#addTeamMember-' + teamNameVal).after(createNewMemberRow(teamNameVal));
	$('#addTeamMember-' + teamNameVal).prop('disabled', true);
}

/**
 * This function is the on click call back for the html elment with id
 * addMember-teamName button.
 * 
 * @param teamName
 *            the team name
 * @returns none
 */
function addMemberButtonOnClickCallBack(teamName) 
{
	memberId = $('#' + teamName.id + '-member').val();
	memberId = memberId.trim();
	if (!memberId) 
	{
		setMemberErrorTextAndShow(MESSAGE_TEAM_MEMBER_EMPTY);
		console.log(MESSAGE_TEAM_MEMBER_EMPTY + ' ' + memberId);
		return;
	}
	invalidCharacters = getInvalidCharacters(memberId);
	if (invalidCharacters)
	{
		setMemberErrorTextAndShow(MESSAGE_INVALID_CHARACTER_USED,
				invalidCharacters);
		console.log(MESSAGE_INVALID_CHARACTER_USED + ' ' + invalidCharacters);
		return;
	}
	ajaxHTTPRequest = getXMLHttpRequestObject();
	ajaxHTTPRequest.onreadystatechange = function() 
	{
		ajaxCallBackForAddMemberTeamPostRequest(ajaxHTTPRequest, teamName.id);
	};
	ajaxHTTPRequest.open('POST', 'createTeam', true);
	ajaxHTTPRequest.setRequestHeader('Content-type',
			'application/x-www-form-urlencoded');
	var requestParameter = 'teamName=' + teamName.id + '&actionType=AddMember'+ '&memberId=' + memberId;
	ajaxHTTPRequest.send(requestParameter);
}

/**
 * This function is ajax call back for add member post request.
 * 
 * @param ajaxHTTPRequest
 *            the xml http request
 * @param teamName
 *            the team name
 * @returns none
 */
function ajaxCallBackForAddMemberTeamPostRequest(ajaxHTTPRequest, teamName) 
{
	if (ajaxHTTPRequest.readyState === AJAX_REQUEST_COMPLETE && ajaxHTTPRequest.status === 200) 
	{
		if (ajaxHTTPRequest.response === RESPONSE_SUCCESS) 
		{
			$('row-member-' + teamName).remove();
			$('#addTeamMember-' + teamName).prop('disabled', false);
		} 
		else if (ajaxHTTPRequest.response === RESPONSE_FAIL_TEAM_MEMBER_EXISTS)
		{
			setMemberErrorTextAndShow(MESSAGE_TEAM_MEMBER_ALREADY_ADDED);
		} 
		else
		{
			setMemberErrorTextAndShow(MESSAGE_ERROR_OCCURED);
		}
	} 
};

/**
 * This function is called to create a new row to add a team member.
 * 
 * @param teamName
 *            the team name
 * @returns none
 */
function createNewMemberRow(teamName)
{
	var newRow = '<tr id="row-member-'
			+ teamName
			+ '">'
			+ '<td ><input type="text" class="form-control" id="'
			+ teamName
			+ '-member"></td>'
			+ '<td>   </td>'
			+ '<td>'
			+ '<button type="button" class="btn btn-primary" id="addMember-'
			+ teamName
			+ '" onClick = "addMemberButtonOnClickCallBack('
			+ teamName
			+ ');">'
			+ '+'
			+ '</button>'
			+ '</td>'
			+ '<td>'
			+ '<span style="color:red" id="create_team_member_error_message">team name already exists</span>'
			+ '</td>' + '</tr>';
	return newRow;
}

/**
 * This function is called to display an error message while adding team member.
 * 
 * @param errorText
 *            the error text
 * @param invalidChars
 *            the invalid characters
 * @returns none
 */
function setMemberErrorTextAndShow(errorText, invalidChars) 
{
	if (invalidChars)
	{
		errorText = errorText + ' ' + invalidChars;
	}
	$('#create_team_member_error_message').text(errorText);
	$('#create_team_member_error_message').show();
}

/**
 * 
 * Function creates a new XMLHttpRequest and returns it.
 * 
 * @return a new XMLHttpRequest object*
 */
function getXMLHttpRequestObject() 
{
    return new XMLHttpRequest();
}

/**
 * It takes a teamName as parameter, attaches it to a table row and then returns
 * the table row.
 * 
 * @param teamName
 *            the teamName is a valid team name to be added to a new table row
 * @returns a table row containing teamName information
 */
function createNewRow(teamName) 
{
    var newRow = '<tr id=row-'+ teamName+ '>' + '<td id=' + teamName + '>' + teamName + '</td>'
            + '<td>'
            + '<button type="button" class="btn btn-primary" id="delete-'
            + teamName + '" onClick = "deleteTeamButtonOnClickCallBack('+teamName+');">' 
            + 'Delete' + '</button>' + '</td>' + '<td>'
            + '</td>' 
            + '<td>'
            + '<button type="button" class="btn btn-primary" id="addTeamMember-'
            + teamName + '" onClick = "addTeamMemberButtonOnClick('+teamName+');">' 
            + 'Add Team Member' + '</button>' + '</td>' + '<td>'
            + '</td>'
            + '</tr>';
    return newRow;
}

/**
 * Function takes a teamName as input, returns a comma separated
 * string of invalid characters if there is any. A valid team name contains only
 * letters a to z, A to z and 0 to 9.
 * 
 * @param teamName
 *            is the name of the team to be validated
 * @returns space separated string of invalid characters if there is any invalid
 *          character, an empty string if there is not any invalid character
 */
function getInvalidCharacters(teamName)
{
    var invalidChars = '';
    var alphaNumeric = /^[A-Za-z0-9]+$/; // combination of one or more letters and numbers
    var currentCharacter;
    for(var i = 0; i < teamName.length; i++)
    {
        currentCharacter = teamName.charAt(i);
        if(!currentCharacter.match(alphaNumeric))
        {
            if(invalidChars === '')
            {
                invalidChars = currentCharacter;
            }
            else
            {
                if (invalidChars.search(currentCharacter) === -1) 
                {
                    invalidChars = invalidChars + ' ' + currentCharacter;
                }
            }
        }
    }
    return invalidChars;
}

/**
 * Function takes a error text and attaches it to the element that is
 * used for error message showing purpose.
 * 
 * @param errorText
 *            the error text to be attached
 * @param invalidChars
 *            invalid characters in the input
 * 
 * @returns none
 */
function setErrorTextAndShow(errorText, invalidChars) 
{
    if(invalidChars)
    {
        errorText = errorText + ' ' + invalidChars;
    }
    $('#alert-danger').text(errorText);
    $('#alert-close')
    $('#alert-danger').show();
}
